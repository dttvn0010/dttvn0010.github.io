from django import forms

class NameForm(forms.Form):
    name = forms.CharField(label='Enter Student name', max_length=100)
    
    def clean_name(self):
    
        name = self.cleaned_data['name']
        
        if not name.startswith('N'):
            raise forms.ValidationError('Name needs to start with \'N\' character : %s', params=(name,), code='not_name_N')
            
        return name
        
    def clean(self):
        cleaned_data = super().clean()
        
        name = self.cleaned_data.get('name', '')
        
        if not name.startswith('N'):
            raise forms.ValidationError(f'Name needs to start with \'N\' character : %s %s', params=(name, name), code='not_name_N_N')
        
        return cleaned_data
        
    