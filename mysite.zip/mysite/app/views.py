from django.shortcuts import render
from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated

@api_view(['GET', 'POST'])
@permission_classes((IsAuthenticated,))
def test_api(request):    
   return Response({"message" : "Hello world!"})
   

def index(request):
    return render(request, 'index.html', {'name' : 'world'})
	
def login(request):
    return render(request, 'login.html')