import os
import cv2
import numpy as np
from keras.models import model_from_json
import time

json_file = 'c1206-cls.json'
h5_file =  'c1206-cls.h5'
img_dir = 'images-c1206'

#json_file = 'sot23-cls-old.json'
#h5_file =  'sot23-cls-old.h5'
#img_dir = 'images-sot23'

with open(json_file) as f: 
	model = model_from_json(f.read())
	
model.load_weights(h5_file)
print(model.summary())

t = time.time()
n_image = 0
for root, dirs, files in os.walk(img_dir):
	for f in files:
		file_path = os.path.join(root, f)
		img = cv2.imread(file_path)
		img = cv2.resize(img, (256,256))
		img = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
		print("Processing file:", file_path)
		model.predict(np.array([img]))
		n_image += 1
		
total_time = time.time() - t 
fps = n_image / total_time		
print(f'Total image {n_image}, total time {time.time()-t} seconds, fps={fps} image/second')
		
