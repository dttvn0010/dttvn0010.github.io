-- phpMyAdmin SQL Dump
-- version 4.5.4.1deb2ubuntu2.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 24, 2019 at 04:29 AM
-- Server version: 5.7.26-0ubuntu0.16.04.1
-- PHP Version: 7.0.33-0ubuntu0.16.04.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `supermarket`
--

-- --------------------------------------------------------

--
-- Table structure for table `stock_warehouse`
--

CREATE TABLE `stock_warehouse` (
  `id` bigint(20) NOT NULL,
  `code` varchar(30) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `stock_warehouse`
--

INSERT INTO `stock_warehouse` (`id`, `code`, `name`) VALUES
(40, 'WHD', 'Sakura Hà Đông'),
(47, 'WHB', 'Sakura Hàng Bông'),
(54, 'WHMG', 'Sakura Hoàng Minh Giám'),
(61, 'WTH', 'Sakura Thái Hà'),
(68, 'WTY', 'Sakura Trung Yên'),
(75, 'WTDN', 'Sakura Trần Đăng Ninh'),
(82, 'WND', 'Sakura Nguyễn Du'),
(175, 'WTC', 'Sakura Times City'),
(198, 'WLD', 'Sakura Linh Đàm');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `stock_warehouse`
--
ALTER TABLE `stock_warehouse`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `stock_warehouse`
--
ALTER TABLE `stock_warehouse`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=199;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
